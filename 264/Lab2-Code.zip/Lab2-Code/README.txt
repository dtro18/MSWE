To compile:
1. cd into lab2-code (or the base directory that contains the source code)
2. execute javac *.java
3. execute java SystemMain Students.txt Courses.txt

logs.txt will be generated upon running the program.