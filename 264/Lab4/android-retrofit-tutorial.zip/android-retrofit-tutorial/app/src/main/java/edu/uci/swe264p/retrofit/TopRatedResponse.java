package edu.uci.swe264p.retrofit;

import java.sql.Array;
import java.util.List;
import java.util.ArrayList;
public class TopRatedResponse {
    private List<Movie> results;

    public TopRatedResponse(List<Movie> results) {
        this.results = results;
    }

    public List<Movie> getTopMovies() {
        return this.results;
    }

}
