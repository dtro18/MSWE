package edu.uci.swe264p.retrofit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

// Feeds data into UI list

public class MovieListAdapter extends RecyclerView.Adapter<MovieListAdapter.ViewHolder> {
    private List<Movie> mMovies;

    MovieListAdapter(List<Movie> movies) {
        this.mMovies = movies;
    }

    // Responsible for displaying a single item with a view
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPoster;
        TextView tvTitle, tvReleaseDate, tvVote, tvOverview;

        ViewHolder(View itemView) {
            super(itemView);
            ivPoster = itemView.findViewById(R.id.ivMovie);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvReleaseDate = itemView.findViewById(R.id.tvReleaseDate);
            tvVote = itemView.findViewById(R.id.tvVote);
            tvOverview = itemView.findViewById(R.id.tvOverview);
        }
    }

    // Create a new viewHolder
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_row, parent, false);
        return new ViewHolder(view);
    }
    // Binding data of a single item to a view
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String posterPath = mMovies.get(position).getPosterPath();
        String imageURL = "https://image.tmdb.org/t/p/w500/" + posterPath;

        String title = mMovies.get(position).getTitle();
        String release = mMovies.get(position).getReleaseDate();
        String vote = mMovies.get(position).getVoteAverage().toString();
        String overview = mMovies.get(position).getOverview();

        holder.tvTitle.setText(title);
        holder.tvReleaseDate.setText(release);
        holder.tvVote.setText(vote);
        holder.tvOverview.setText(overview);
        Picasso.get().load(imageURL).into(holder.ivPoster);

    }
    // Get size of dataset
    @Override
    public int getItemCount() {
        return mMovies.size();
    }
}