For testing, the project was built with JDK17 and Gradle 8.10. Additionally, Picasso 2.71828 was used.
Android studio has some methods to install a version of JDK17.

From there, select Build (The hammer icon) in the bottom left corner to build the app.
The app was run using Medium Phone API 35. Run can be found in the taskbar.
